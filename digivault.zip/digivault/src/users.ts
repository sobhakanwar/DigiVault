export class users
{
  static email(email: any) {
    throw new Error('Method not implemented.')
  }
  public email?:string
  public password?:string
  public role?:string
}
