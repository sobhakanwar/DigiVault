package com.Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigiVaultRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigiVaultRestApiApplication.class, args);
	}

}
