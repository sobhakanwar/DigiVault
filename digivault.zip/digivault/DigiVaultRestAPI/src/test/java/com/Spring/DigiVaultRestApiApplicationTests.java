package com.Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigiVaultRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
